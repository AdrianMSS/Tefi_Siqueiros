// Added for convenience in the Node environment.
// The meat and potatoes exist in ./lib/polyglot.js.
module.exports = require('./lib/polyglot');
